// Ввод размера поля
do {
    var XY = prompt('Веддите размер поля для игры x-y, но неменее 10-10:', '20-20');
} while (parseInt(XY.split('-')[0]) < 10 && parseInt(XY.split('-')[1]) < 10 && XY !== null);


var FIELD_SIZE_X = parseInt(XY.split('-')[0]);
var FIELD_SIZE_Y = parseInt(XY.split('-')[1]);

//var FIELD_SIZE_X = 20;
//var FIELD_SIZE_Y = 20;


//Глобальные переменные
var SNAKE_SPEED = 300; //300мс
var snake = []; //Сама змейка
var direction = 'y+'; //Направление движения змейки
var oldDirection = 'y+'; //Старое направление движения змейки
var gameIsRunning = false; //Запущена ли игра
var snakeTimer; //Таймер змейки
var trapTimer; //Таймер ловушки
var scoreBoard; //Табло
var score = 0; //Результат
var remain; //Остаток до победы
var wrap = document.getElementsByClassName('wrap')[0];
var finishCondition = FIELD_SIZE_X * FIELD_SIZE_Y - Math.floor(FIELD_SIZE_X * FIELD_SIZE_Y / 2);



//Генерация поля
prepareGameField();


//Подгоняем размер контейнера под игровое поле
if(16 * (FIELD_SIZE_X + 1) < 200){
    wrap.style.width = '200px';
} else {
    wrap.style.width = (16 * (FIELD_SIZE_X + 1)).toString() + 'px';
}


//Если нажата кнопка новая игра
document.getElementById('snake-new-game').addEventListener('click', startGame);
addEventListener('keydown', changeDirection);

function prepareGameField() {
    //Создаем таблицу
    var gameTable = document.createElement('table');
    gameTable.classList.add('game-table');
    //Генерация ячеек для игровой таблицы
    for (var i = 0; i < FIELD_SIZE_Y; i++){
        var row = document.createElement('tr');
        row.classList.add('game-table-row');

        for (var j = 0; j < FIELD_SIZE_X; j++)
        {
            var cell = document.createElement('td');
            cell.classList.add('game-table-cell');
            cell.classList.add('cell-' + i + '-' + j);
            row.appendChild(cell);
        }
        gameTable.appendChild(row);
    }
    document.getElementById('snake-field').appendChild(gameTable);
    //Создаем табло
    scoreBoard = document.createElement('div');
    scoreBoard.id = 'score-field';
    wrap.insertBefore(scoreBoard, wrap.children[1]);
}

//Старт игры
function startGame() {
    gameIsRunning = true;
    //Сброс предыдущей игры
    direction = 'y+';
    oldDirection = 'y+';
    score = 0;
    scoreBoard.innerText = 'Ваш результат: ' + score + ' очков\n' + 'До победы осталось набрать ' + finishCondition + ' очков';

    for (var i = 0; i < snake.length; i++) {
        snake[i].classList.remove('snake-unit');
    }
    snake = [];

    var units = document.getElementsByClassName('food-unit');
    for (i = 0; i < units.length; i++) {
        units[i].classList.remove('food-unit');
    }

    var traps = document.getElementsByClassName('trap-unit');
    for (i = 0; i < traps.length; i++) {
        traps[i].classList.remove('trap-unit');
    }

    //Начало новой игры
    clearInterval(snakeTimer);
    clearInterval(trapTimer);
    respawn();
    snakeTimer = setInterval(move, SNAKE_SPEED);
    trapTimer = setInterval(createTrap, 40000 - FIELD_SIZE_X * FIELD_SIZE_Y * 15);
    setTimeout(createFood, 5000);
}

//Метод отвечает за расположение змейки в игровом поле
function respawn() {
    var startCoordsX = Math.floor(FIELD_SIZE_X / 2);
    var startCoordsY = Math.floor(FIELD_SIZE_Y / 2);
    //Голова змейки
    var snakeHead = document.getElementsByClassName('cell-' + startCoordsY + '-' + startCoordsX)[0];
    snakeHead.classList.add('snake-unit');
    snakeHead.setAttribute('data_y', startCoordsY.toString());
    snakeHead.setAttribute('data_x', startCoordsX.toString());
    //Тело змейки
    var snakeBody = document.getElementsByClassName('cell-' + (startCoordsY + 1) + '-' + startCoordsX)[0];
    snakeBody.classList.add('snake-unit');
    snake.push(snakeBody);
    snake.push(snakeHead);
}

//Движение змейки
function move() {
    var newUnit; //Новый элемент
    var coordY = parseInt(snake[snake.length - 1].getAttribute('data_y'));
    var coordX = parseInt(snake[snake.length - 1].getAttribute('data_x'));

    //Определяем новую точку
    switch (direction)
    {
        case 'x-':
            if (coordX - 1 < 0) {
                coordX = FIELD_SIZE_X;
            }
            newUnit = document.querySelector('.cell-' + (coordY) + '-' + (coordX -= 1));
            break;
        case 'x+':
            if (coordX + 1 > FIELD_SIZE_X - 1) {
                coordX = -1;
            }
            newUnit = document.querySelector('.cell-' + (coordY) + '-' + (coordX += 1));
            break;
        case 'y-':
            if (coordY + 1 > FIELD_SIZE_Y - 1) {
                coordY = -1;
            }
            newUnit = document.querySelector('.cell-' + (coordY += 1) + '-' + (coordX));
            break;
        case 'y+':
            if (coordY - 1 < 0) {
                coordY = FIELD_SIZE_Y;
            }
            newUnit = document.querySelector('.cell-' + (coordY -= 1) + '-' + (coordX));
            break;
    }

    //Проверка. Не является ли новая часть частью змейки и не выходит ли за границы
    if(snake.indexOf(newUnit) === -1 && !newUnit.classList.contains('trap-unit')) {
        snake[snake.length - 1].removeAttribute('data_y');
        snake[snake.length - 1].removeAttribute('data_x');

        newUnit.classList.add('snake-unit');
        snake.push(newUnit);
        snake[snake.length - 1].setAttribute('data_y', coordY.toString());
        snake[snake.length - 1].setAttribute('data_x', coordX.toString());

        //Хвост. Проверка
        if (!haveFood(newUnit)) {
            //Перемещаем хвост если не съедена еда
            snake.splice(0, 1)[0].classList.remove('snake-unit');
        }
    } else {
        if (newUnit.classList.contains('trap-unit')) {
            newUnit.classList.remove('trap-unit');
            var bang = document.createElement('div');
            bang.classList.add('bang');
            bang.style.top = coordY * 15.5 - 3 + 'px';
            bang.style.left = coordX * 15.5 - 3 + 'px';
            wrap.insertBefore(bang, wrap.children[0]);
            setTimeout(removeBang, 3000);
        }
        //Заканчиваем игру
        finishGame();
    }
    oldDirection = direction;
}

//Создание еды
function createFood() {
    var foodCreated = false;
    while (!foodCreated)
    {
        var foodX = Math.floor(Math.random() * FIELD_SIZE_X);
        var foodY = Math.floor(Math.random() * FIELD_SIZE_Y);

        //Проверка на змейку
        var foodCell = document.querySelector('.cell-' + foodY + '-' + foodX);
        if(!foodCell.classList.contains('snake-unit') && !foodCell.classList.contains('food-unit') && !foodCell.classList.contains('trap-unit')){
            foodCell.classList.add('food-unit');
            foodCreated = true;
        }
    }
}

//Проверка на еду
function haveFood(unit) {
    if(unit.classList.contains('food-unit')){
        unit.classList.remove('food-unit');
        createFood();
        score++;
        remain = finishCondition - score;
        if (remain <= 0) {
            scoreBoard.innerText = 'Ваш результат: ' + score + ' очков';
        } else {
            scoreBoard.innerText = 'Ваш результат: ' + score + '\nДо победы осталось набрать ' + remain + ' очков';
        }
        return true;
    }
    return false;
}

//Завершение игры
function finishGame() {
    gameIsRunning = false;
    clearInterval(snakeTimer);
    clearInterval(trapTimer);
    scoreBoard.innerText = '';
    //Чтобы победить, необходимо заполнить змейкой половину клеток
    if(score < finishCondition){
        scoreBoard.innerText = 'Игра окончена!\nВаш результат: ' + score.toString() + ' очков';
    } else {
        scoreBoard.innerText = 'Поздравляем! Вы победили!\nВаш результат: ' + score.toString() + ' очков';
    }
}

function changeDirection(event) {
    switch (event.keyCode)
    {
        case 37: //Клавиша влево
            if(oldDirection !== 'x+'){
            direction = 'x-'
            }
            break;
        case 38: //Клавиша вверх
            if(oldDirection !== 'y-'){
            direction = 'y+';
            }
            break;
        case 39: //Клавиша вправо
            if(oldDirection !== 'x-'){
                direction = 'x+';
            }
            break;
        case 40: //Клавиша вниз
            if(oldDirection !== 'y+'){
                direction = 'y-';
            }
            break;
    }
}

function createTrap() {
    var trapCreated = false;
    while (!trapCreated)
    {
        var trapX = Math.floor((Math.random() * (0.95 - 0.05) + 0.05) * FIELD_SIZE_X);
        var trapY = Math.floor((Math.random() * (0.95 - 0.05) + 0.05) * FIELD_SIZE_Y);

        //Проверка на змейку
        var trapCell = document.querySelector('.cell-' + trapY + '-' + trapX);
        if(!trapCell.classList.contains('snake-unit') && !trapCell.classList.contains('food-unit') && !trapCell.classList.contains('trap-unit')){
            trapCell.classList.add('trap-unit');
            trapCreated = true;
        }
    }
}

function removeBang() {
    var bang = document.getElementsByClassName('bang')[0];
    bang.parentNode.removeChild(bang);
}